# Hardware

Approved hardware and production statuses.

---

TODO
